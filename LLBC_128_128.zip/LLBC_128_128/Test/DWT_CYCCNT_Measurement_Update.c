#include <stdint.h>

#define DEMCR        (*(volatile uint32_t *)0xE000EDFCu)
#define DWT_CTRL     (*(volatile uint32_t *)0xE0001000u)
#define DWT_CYCCNT   (*(volatile uint32_t *)0xE0001004u)
#define DWT_CPICNT   (*(volatile uint32_t *)0xE0001008u)
#define DWT_EXCCNT   (*(volatile uint32_t *)0xE000100Cu)
#define DWT_SLEEPCNT (*(volatile uint32_t *)0xE0001010u)
#define DWT_LSUCNT   (*(volatile uint32_t *)0xE0001014u)
#define DWT_FOLDCNT  (*(volatile uint32_t *)0xE0001018u)
#define CPUID_REG    (*(volatile uint32_t *)0xE000ED00u)
#define DBGMCU_IDCODE (*(volatile uint32_t *)0xE0042000u)
#define RCC_CFGR     (*(volatile uint32_t *)0x40021004u)
#define FLASH_ACR    (*(volatile uint32_t *)0x40022000u)

#define DEMCR_TRCENA       (1u << 24)
#define DWT_CYCCNTENA      (1u << 0)
#define DWT_EVENT_ENABLE   ((1u << 17) | (1u << 18) | (1u << 19) | \
                            (1u << 20) | (1u << 21))
#define BENCH_REPETITIONS  1000u
#define WARMUP_REPETITIONS 100u

extern uint32_t SystemCoreClock;
extern void SystemCoreClockUpdate(void);
extern void LLBC128_precomputed_call(uint32_t out[4],
                                    const uint32_t plaintext[4],
                                    uint32_t key_workspace[80]);
extern void LLBC128_precomputed_empty(uint32_t out[4],
                                     const uint32_t plaintext[4],
                                     uint32_t key_workspace[80]);

static const uint32_t test_plaintexts[3][4] = {
    { 0x00112233u, 0x44556677u, 0x8899aabbu, 0xccddeeffu },
    { 0x00000000u, 0x00000000u, 0x00000000u, 0x00000000u },
    { 0xFFFFFFFFu, 0xFFFFFFFFu, 0xFFFFFFFFu, 0xFFFFFFFFu }
};

static const uint32_t test_keys[3][4] = {
    { 0x01234567u, 0x89abcdefu, 0xfedcba98u, 0x76543210u },
    { 0xFFFFFFFFu, 0xFFFFFFFFu, 0xFFFFFFFFu, 0xFFFFFFFFu },
    { 0x00000000u, 0x00000000u, 0x00000000u, 0x00000000u }
};

static const uint32_t expected[3][4] = {
    { 0x9f310b4cu, 0xb3dbe6c8u, 0x1aa093d0u, 0x5c482f71u },
    { 0x98CD89BAu, 0x50A62B59u, 0x2AE8AE85u, 0xCBEDD2E7u },
    { 0xF5D7D1ACu, 0xCD73C69Cu, 0x17E638B4u, 0x773F33C1u }
};

uint32_t ciphertext[3][4];
volatile uint32_t key_workspace[80];
uint32_t cycle_samples[BENCH_REPETITIONS];

volatile uint32_t vector_pass_mask;
volatile uint32_t vector_failure_mask;
volatile uint32_t dwt_available;
volatile uint32_t measured_core_clock_hz;
volatile uint32_t measured_rcc_cfgr;
volatile uint32_t measured_flash_acr;
volatile uint32_t measured_cpuid;
volatile uint32_t measured_dbgmcu_idcode;
volatile uint32_t cycles_counter_read_overhead;
volatile uint32_t cycles_single_raw;
volatile uint32_t cycles_reset_only_total;
volatile uint32_t cycles_empty_wrapper_total;
volatile uint32_t cycles_full_wrapper_total;
volatile uint32_t cycles_including_call_total;
volatile uint32_t cycles_core_net_total;
volatile uint32_t sample_min;
volatile uint32_t sample_median_x2;
volatile uint32_t sample_max;
volatile uint32_t sample_sum_lo;
volatile uint32_t sample_sum_hi;
volatile uint32_t sample_sumsq_lo;
volatile uint32_t sample_sumsq_hi;
volatile uint32_t event_full_cpi;
volatile uint32_t event_full_exc;
volatile uint32_t event_full_sleep;
volatile uint32_t event_full_lsu;
volatile uint32_t event_full_fold;
volatile uint32_t event_empty_cpi;
volatile uint32_t event_empty_exc;
volatile uint32_t event_empty_sleep;
volatile uint32_t event_empty_lsu;
volatile uint32_t event_empty_fold;
volatile uint32_t bench_done;
volatile uint32_t progress_stage;
volatile uint32_t fault_cfsr;
volatile uint32_t fault_hfsr;

__attribute__((noinline))
void LLBC128_benchmark_complete(void)
{
    __asm volatile ("nop");
}

__attribute__((noinline))
void HardFault_Handler(void)
{
    fault_cfsr = *(volatile uint32_t *)0xE000ED28u;
    fault_hfsr = *(volatile uint32_t *)0xE000ED2Cu;
    bench_done = 0xDEADu;
    LLBC128_benchmark_complete();
    for (;;) {
        __asm volatile ("nop");
    }
}

__attribute__((noinline))
static void LLBC128_reset_key_workspace(const uint32_t raw_key[4])
{
    key_workspace[0] = raw_key[0];
    key_workspace[1] = raw_key[1];
    key_workspace[2] = raw_key[2];
    key_workspace[3] = raw_key[3];
    __asm volatile ("" : : : "memory");
}

static void LLBC128_dwt_enable(void)
{
    DEMCR |= DEMCR_TRCENA;
    DWT_CYCCNT = 0u;
    DWT_CTRL |= DWT_CYCCNTENA;
    dwt_available = ((DWT_CTRL & DWT_CYCCNTENA) != 0u);
}

static __inline uint32_t LLBC128_cycle_now(void)
{
    __asm volatile ("" : : : "memory");
    return DWT_CYCCNT;
}

static void LLBC128_reset_event_counters(void)
{
    DWT_CTRL &= ~DWT_EVENT_ENABLE;
    DWT_CPICNT = 0u;
    DWT_EXCCNT = 0u;
    DWT_SLEEPCNT = 0u;
    DWT_LSUCNT = 0u;
    DWT_FOLDCNT = 0u;
    DWT_CTRL |= DWT_EVENT_ENABLE;
}

static void LLBC128_stop_event_counters(void)
{
    DWT_CTRL &= ~DWT_EVENT_ENABLE;
}

static void LLBC128_sort_samples(void)
{
    uint32_t gap;
    uint32_t i;
    for (gap = BENCH_REPETITIONS / 2u; gap != 0u; gap /= 2u) {
        for (i = gap; i < BENCH_REPETITIONS; ++i) {
            uint32_t value = cycle_samples[i];
            uint32_t j = i;
            while ((j >= gap) && (cycle_samples[j - gap] > value)) {
                cycle_samples[j] = cycle_samples[j - gap];
                j -= gap;
            }
            cycle_samples[j] = value;
        }
    }
}

int main(void)
{
    uint32_t start;
    uint32_t stop;
    uint32_t saved_primask;
    uint32_t i;
    uint32_t overhead_best = 0xFFFFFFFFu;
    uint64_t sum = 0u;
    uint64_t sumsq = 0u;

    progress_stage = 1u;
    LLBC128_dwt_enable();
    SystemCoreClockUpdate();
    measured_core_clock_hz = SystemCoreClock;
    measured_rcc_cfgr = RCC_CFGR;
    measured_flash_acr = FLASH_ACR;
    measured_cpuid = CPUID_REG;
    measured_dbgmcu_idcode = DBGMCU_IDCODE;

    vector_pass_mask = 0u;
    vector_failure_mask = 0u;
    for (i = 0u; i < 3u; ++i) {
        LLBC128_reset_key_workspace(test_keys[i]);
        LLBC128_precomputed_call(ciphertext[i], test_plaintexts[i],
                                (uint32_t *)key_workspace);
        if ((ciphertext[i][0] == expected[i][0]) &&
            (ciphertext[i][1] == expected[i][1]) &&
            (ciphertext[i][2] == expected[i][2]) &&
            (ciphertext[i][3] == expected[i][3])) {
            vector_pass_mask |= (1u << i);
        } else {
            vector_failure_mask |= (1u << i);
        }
    }
    progress_stage = 2u;

    __asm volatile ("mrs %0, primask" : "=r" (saved_primask));
    __asm volatile ("cpsid i" : : : "memory");

    for (i = 0u; i < 32u; ++i) {
        start = LLBC128_cycle_now();
        stop = LLBC128_cycle_now();
        if ((stop - start) < overhead_best) {
            overhead_best = stop - start;
        }
    }
    cycles_counter_read_overhead = overhead_best;

    for (i = 0u; i < WARMUP_REPETITIONS; ++i) {
        LLBC128_reset_key_workspace(test_keys[0]);
        LLBC128_precomputed_call(ciphertext[0], test_plaintexts[0],
                                (uint32_t *)key_workspace);
    }

    LLBC128_reset_key_workspace(test_keys[0]);
    start = LLBC128_cycle_now();
    LLBC128_precomputed_call(ciphertext[0], test_plaintexts[0],
                            (uint32_t *)key_workspace);
    cycles_single_raw = LLBC128_cycle_now() - start;

    start = LLBC128_cycle_now();
    for (i = 0u; i < BENCH_REPETITIONS; ++i) {
        LLBC128_reset_key_workspace(test_keys[0]);
        __asm volatile ("" : : : "memory");
    }
    cycles_reset_only_total = LLBC128_cycle_now() - start;

    start = LLBC128_cycle_now();
    for (i = 0u; i < BENCH_REPETITIONS; ++i) {
        LLBC128_reset_key_workspace(test_keys[0]);
        LLBC128_precomputed_empty(ciphertext[0], test_plaintexts[0],
                                 (uint32_t *)key_workspace);
    }
    cycles_empty_wrapper_total = LLBC128_cycle_now() - start;

    start = LLBC128_cycle_now();
    for (i = 0u; i < BENCH_REPETITIONS; ++i) {
        LLBC128_reset_key_workspace(test_keys[0]);
        LLBC128_precomputed_call(ciphertext[0], test_plaintexts[0],
                                (uint32_t *)key_workspace);
    }
    cycles_full_wrapper_total = LLBC128_cycle_now() - start;
    cycles_including_call_total = cycles_full_wrapper_total - cycles_reset_only_total;
    cycles_core_net_total = cycles_full_wrapper_total - cycles_empty_wrapper_total;
    progress_stage = 3u;

    for (i = 0u; i < BENCH_REPETITIONS; ++i) {
        uint32_t delta;
        LLBC128_reset_key_workspace(test_keys[0]);
        start = LLBC128_cycle_now();
        LLBC128_precomputed_call(ciphertext[0], test_plaintexts[0],
                                (uint32_t *)key_workspace);
        stop = LLBC128_cycle_now();
        delta = stop - start;
        cycle_samples[i] = (delta >= overhead_best) ? (delta - overhead_best) : 0u;
    }

    LLBC128_reset_key_workspace(test_keys[0]);
    LLBC128_reset_event_counters();
    LLBC128_precomputed_call(ciphertext[0], test_plaintexts[0],
                            (uint32_t *)key_workspace);
    event_full_cpi = DWT_CPICNT & 0xFFu;
    event_full_exc = DWT_EXCCNT & 0xFFu;
    event_full_sleep = DWT_SLEEPCNT & 0xFFu;
    event_full_lsu = DWT_LSUCNT & 0xFFu;
    event_full_fold = DWT_FOLDCNT & 0xFFu;
    LLBC128_stop_event_counters();

    LLBC128_reset_key_workspace(test_keys[0]);
    LLBC128_reset_event_counters();
    LLBC128_precomputed_empty(ciphertext[0], test_plaintexts[0],
                             (uint32_t *)key_workspace);
    event_empty_cpi = DWT_CPICNT & 0xFFu;
    event_empty_exc = DWT_EXCCNT & 0xFFu;
    event_empty_sleep = DWT_SLEEPCNT & 0xFFu;
    event_empty_lsu = DWT_LSUCNT & 0xFFu;
    event_empty_fold = DWT_FOLDCNT & 0xFFu;
    LLBC128_stop_event_counters();

    if ((saved_primask & 1u) == 0u) {
        __asm volatile ("cpsie i" : : : "memory");
    }

    for (i = 0u; i < BENCH_REPETITIONS; ++i) {
        uint64_t value = cycle_samples[i];
        sum += value;
        sumsq += value * value;
    }
    LLBC128_sort_samples();
    sample_min = cycle_samples[0];
    sample_median_x2 = cycle_samples[(BENCH_REPETITIONS / 2u) - 1u] +
                       cycle_samples[BENCH_REPETITIONS / 2u];
    sample_max = cycle_samples[BENCH_REPETITIONS - 1u];
    sample_sum_lo = (uint32_t)sum;
    sample_sum_hi = (uint32_t)(sum >> 32);
    sample_sumsq_lo = (uint32_t)sumsq;
    sample_sumsq_hi = (uint32_t)(sumsq >> 32);

    vector_pass_mask = 0u;
    vector_failure_mask = 0u;
    for (i = 0u; i < 3u; ++i) {
        LLBC128_reset_key_workspace(test_keys[i]);
        LLBC128_precomputed_call(ciphertext[i], test_plaintexts[i],
                                (uint32_t *)key_workspace);
        if ((ciphertext[i][0] == expected[i][0]) &&
            (ciphertext[i][1] == expected[i][1]) &&
            (ciphertext[i][2] == expected[i][2]) &&
            (ciphertext[i][3] == expected[i][3])) {
            vector_pass_mask |= (1u << i);
        } else {
            vector_failure_mask |= (1u << i);
        }
    }

    progress_stage = 4u;
    bench_done = 1u;
    LLBC128_benchmark_complete();
    for (;;) {
        __asm volatile ("nop");
    }
}
