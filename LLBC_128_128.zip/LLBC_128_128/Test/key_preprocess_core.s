/* Generate and store 20 LLBC round keys. r0 = output (80 words), r1 = raw key (4 words). */
.syntax unified
.cpu cortex-m3
.thumb

.equ RK_PTR,      4
.equ LOCAL_SIZE, 12

.macro ror_16bit   in, out, M0, M1, n0, n1, tmp
	and     \tmp, \M0, \in, lsr \n0
	and     \out, \in, \M1
	orr     \out, \tmp, \out, lsl \n1
.endm

.macro RKEY_update  M0, M1, M2, M3
	EOR   R0, R9,  #((\M0) >> 24)
	EOR   R1, R10, #((\M1) >> 24)
	EOR   R2, R11, #((\M2) >> 24)
	EOR   R3, R12, #((\M3) >> 24)

	ldr   R8, [SP, #RK_PTR]
	stmia R8!, {R0-R3}
	str   R8, [SP, #RK_PTR]

	AND R3, R12, #0x0000f000
	MOV R14, #0x00001000
	ror_16bit  R9, R0, R14, #0x00007000, #3, #1, R8
	ror_16bit  R10, R1, R14, #0x00007000, #3, #1, R8
	ror_16bit  R11, R2, R14, #0x00007000, #3, #1, R8

	ORR R3, R3, R3, LSR #8
	ORR R0, R0, R0, LSR #8
	ORR R1, R1, R1, LSR #8
	ORR R2, R2, R2, LSR #8

	AND R5, R10, #0x00000f00
	AND R6, R11, #0x00000f00
	AND R7, R12, #0x00000f00

	mov R14, #0x01000100
	ror_16bit  R9, R4, R14, #0x07000700, #3, #1, R8

	ORR R3, R3, R5
	ORR R0, R0, R6
	ORR R1, R1, R7
	ORR R2, R2, R4
	ORR R3, R3, R5, LSR #8
	ORR R0, R0, R6, LSR #8
	ORR R1, R1, R7, LSR #8
	ORR R2, R2, R4, LSR #8

	AND R8, R9, #0x000000ff
	EOR R3, R3, R8, LSL #8
	AND R5, R10, #0x000000ff
	EOR R0, R0, R5, LSL #8
	AND R6, R11, #0x000000ff
	EOR R1, R1, R6, LSL #8
	AND R7, R12, #0x000000ff
	EOR R2, R2, R7, LSL #8

	ORR R4, R3, R9, LSL #16
	ORR R5, R0, R10, LSL #16
	ORR R6, R1, R11, LSL #16
	ORR R7, R2, R12, LSL #16

	AND R3, R7, #0x0000f000

	MOV R14, #0x00001000
	ror_16bit  R4, R0, R14, #0x00007000, #3, #1, R8
	ror_16bit  R5, R1, R14, #0x00007000, #3, #1, R8
	ror_16bit  R6, R2, R14, #0x00007000, #3, #1, R8

	ORR R3, R3, R3, LSR #8
	ORR R0, R0, R0, LSR #8
	ORR R1, R1, R1, LSR #8
	ORR R2, R2, R2, LSR #8

	AND R8, R4, #0x000000ff
	EOR R3, R3, R8, LSL #8
	AND R8, R5, #0x000000ff
	EOR R0, R0, R8, LSL #8
	AND R8, R6, #0x000000ff
	EOR R1, R1, R8, LSL #8
	AND R8, R7, #0x000000ff
	EOR R2, R2, R8, LSL #8

	AND R4, R4, #0x00000f00
	AND R5, R5, #0x00000f00
	AND R6, R6, #0x00000f00
	AND R7, R7, #0x00000f00

	mov R14, #0x01000100
	ror_16bit  R4, R4, R14, #0x07000700, #3, #1, R8

	EOR R3, R3, R5
	EOR R0, R0, R6
	EOR R1, R1, R7
	EOR R2, R2, R4
	ORR R3, R3, R5, LSR #8
	ORR R0, R0, R6, LSR #8
	ORR R1, R1, R7, LSR #8
	ORR R2, R2, R4, LSR #8

	EOR R9, R9, R3, LSL #16
	EOR R10, R10, R0, LSL #16
	EOR R11, R11, R1, LSL #16
	EOR R12, R12, R2, LSL #16

	EOR R9, R9, #((\M0)>>8)
	EOR R10, R10, #((\M1)>>8)
	EOR R11, R11, #((\M2)>>8)
	EOR R12, R12, #((\M3)>>8)

	ROR R9,  R9,  #16
	ROR R10, R10, #16
	ROR R11, R11, #16
	ROR R12, R12, #16
.endm

.macro SWAPMOVE  in0, in1, M, n, tmp
    eor     \tmp, \in1, \in0, lsr \n
    and     \tmp, \tmp,\M
    eor     \in1, \in1, \tmp
    eor     \in0, \in0, \tmp, lsl \n
.endm

.macro LLBC_opt_Rkey
	SWAPMOVE  R10, R9, #0x0f0f0f0f, #4, R8
	SWAPMOVE  R12, R11, #0x0f0f0f0f, #4, R8
	SWAPMOVE  R10, R9, #0x55555555, #1, R8
	SWAPMOVE  R12, R11, #0x55555555, #1, R8
	SWAPMOVE  R10, R9, #0x00ff00ff, #8, R8
	SWAPMOVE  R12, R11, #0x00ff00ff, #8, R8
	SWAPMOVE  R10, R9, #0x33333333, #2, R8
	SWAPMOVE  R12, R11, #0x33333333, #2, R8
	lsr R3, R10,#16
	bfi R10, R9,#16,#16
	bfi R9, R3, #0, #16
	lsr R3, R12,#16
	bfi R12, R11,#16,#16
	bfi R11, R3, #0, #16
	SWAPMOVE  R10, R9, #0x0f0f0f0f, #4, R8
	SWAPMOVE  R12, R11, #0x0f0f0f0f, #4, R8
	SWAPMOVE  R10, R9, #0x00ff00ff, #8, R8
	SWAPMOVE  R12, R11, #0x00ff00ff, #8, R8
	lsr R3, R11,#16
	bfi R11, R9,#16,#16
	bfi R9, R3, #0, #16
	lsr R3, R12,#16
	bfi R12, R10,#16,#16
	bfi R10, R3, #0, #16

RKEY_update   0x17000000, 0x58000000, 0xbc000000, 0x30000000
RKEY_update   0x58000000, 0xbc000000, 0x30000000, 0x2e000000
RKEY_update   0xbc000000, 0x30000000, 0x2e000000, 0xb0000000
RKEY_update   0x30000000, 0x2e000000, 0xb0000000, 0x79000000
RKEY_update   0x2e000000, 0xb0000000, 0x79000000, 0x60000000
RKEY_update   0xb0000000, 0x79000000, 0x60000000, 0x5c000000
RKEY_update   0x79000000, 0x60000000, 0x5c000000, 0x61000000
RKEY_update   0x60000000, 0x5c000000, 0x61000000, 0xf2000000
RKEY_update   0x5c000000, 0x61000000, 0xf2000000, 0xc0000000
RKEY_update   0x61000000, 0xf2000000, 0xc0000000, 0xb8000000
RKEY_update   0xf2000000, 0xc0000000, 0xb8000000, 0xc2000000
RKEY_update   0xc0000000, 0xb8000000, 0xc2000000, 0xe5000000
RKEY_update   0xb8000000, 0xc2000000, 0xe5000000, 0x81000000
RKEY_update   0xc2000000, 0xe5000000, 0x81000000, 0x71000000
RKEY_update   0xe5000000, 0x81000000, 0x71000000, 0x85000000
RKEY_update   0x81000000, 0x71000000, 0x85000000, 0xcb000000
RKEY_update   0x71000000, 0x85000000, 0xcb000000, 0x03000000
RKEY_update   0x85000000, 0xcb000000, 0x03000000, 0xe2000000
RKEY_update   0xcb000000, 0x03000000, 0xe2000000, 0x0b000000

EOR   R0, R9,  #0x00000003
EOR   R1, R10, #0x000000e2
EOR   R2, R11, #0x0000000b
EOR   R3, R12, #0x00000097
ldr   R8, [SP, #RK_PTR]
stmia R8!, {R0-R3}
str   R8, [SP, #RK_PTR]
.endm

.text
.align 2
.global LLBC128_prepare_round_keys
.type LLBC128_prepare_round_keys,%function
.thumb_func
LLBC128_prepare_round_keys:
    PUSH    {R4-R11, R14}
    SUB     SP, SP, #LOCAL_SIZE
    STR     R0, [SP, #RK_PTR]
    LDMIA   R1, {R9-R12}
    LLBC_opt_Rkey
    ADD     SP, SP, #LOCAL_SIZE
    POP     {R4-R11, PC}
.size LLBC128_prepare_round_keys,.-LLBC128_prepare_round_keys
