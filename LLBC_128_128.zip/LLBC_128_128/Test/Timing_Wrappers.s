.syntax unified
.thumb
.text
.align 2

.global LLBC128_precomputed_call
.type LLBC128_precomputed_call,%function
.thumb_func
LLBC128_precomputed_call:
    /* R0=out[4], R1=plaintext[4], R2=key_workspace[80]. */
    push    {R0,R4-R11,LR}
    ldmia   R1,{R4-R7}
    stmia   R0,{R4-R7}
    mov     R1,R2
    bl      LLBC_encrypt_block
    pop     {R0,R4-R11,PC}
.size LLBC128_precomputed_call,.-LLBC128_precomputed_call

.global LLBC128_precomputed_empty
.type LLBC128_precomputed_empty,%function
.thumb_func
LLBC128_precomputed_empty:
    /* Instruction-for-instruction matched wrapper baseline. */
    push    {R0,R4-R11,LR}
    ldmia   R1,{R4-R7}
    stmia   R0,{R4-R7}
    mov     R1,R2
    bl      LLBC128_precomputed_empty_core
    pop     {R0,R4-R11,PC}
.size LLBC128_precomputed_empty,.-LLBC128_precomputed_empty

.type LLBC128_precomputed_empty_core,%function
.thumb_func
LLBC128_precomputed_empty_core:
    bx      LR
.size LLBC128_precomputed_empty_core,.-LLBC128_precomputed_empty_core
