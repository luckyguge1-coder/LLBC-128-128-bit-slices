.syntax unified
.cpu cortex-m3
.thumb

.equ PT_PTR,      0       /* SP+0：plaintext address */
.equ RK_PTR,      4       /* SP+4：key update address*/
.equ ENC_RK_PTR,  8       /* SP+8：rkey address*/
.equ LOCAL_SIZE, 12       /* get 12 byte */


.macro ror_16bit   in, out, M0, M1, n0, n1, tmp
	and     \tmp, \M0, \in, lsr \n0
	and     \out, \in, \M1
	orr     \out, \tmp, \out, lsl \n1
.endm

.macro S1_box  in0, in1, in2, in3, tmp
	/* 12-instruction, five-register.  Both 16-bit copies are processed together.
	 *  Input x3/x2/x1/x0 is in in0/in1/in2/in3; 
	 *  output y3/y2/y1/y0 is left in in2/in3/in0/in1. */
	EOR    \in1, \in1, \in2
	ORR   \tmp, \in0, \in1
	EOR   \in2, \in2, \tmp
	AND   \tmp, \in2, \in3
	EOR   \in1, \in1, \tmp
	BIC   \tmp, \in3, \in1
	EOR   \in0, \in0, \tmp
	EOR   \in1,\in1, \in2
	ORN   \tmp, \in1, \in0
	EOR   \in3, \in3, \tmp
	AND   \tmp, \in0, \in3
	EOR   \in1, \in1, \tmp
.endm

.macro S2_box  in0, in1, in2, in3, tmp
	/* 13-instruction, five-register. Both 16-bit copies are processed together. 
	 *  Input x3/x2/x1/x0 is in in0/in1/in2/in3; 
	 * output y3/y2/y1/y0 is left in in1/in3/in0/in2. */
	EOR   \in1, \in1, \in2
	ORN   \tmp, \in3, \in1
	EOR   \in0, \in0, \tmp
	ORN   \tmp, \in1, \in0
	EOR   \in2, \in2, \tmp
	ORR   \tmp, \in2, \in3
	EOR   \in0, \in0, \tmp
	BIC   \tmp, \in3, \in2
	EOR   \in1, \in1, \tmp
	BIC   \tmp, \in0, \in1
	EOR   \in3, \in3, \tmp
	AND   \tmp, \in0, \in3
	EOR   \in1, \in1, \tmp
.endm

/* Input A=S1 in R5/R6/R7/R4; B=S2 in R9/R11/R12/R10.
 * A and B are duplicated in both halfwords.  low selects the state half
 * that receives M(A,B). */
.macro MixWord low
	/* X = A xor B. */
	EOR R9, R9, R5
	EOR R11, R11, R6
	EOR R12, R12, R7
	EOR R10, R10, R4
	/* Y = A xor ROL64(X,3). */
	EOR R5,  R5,  R10
	EOR R6, R6, R9, ROR #15
	EOR R7, R7, R11, ROR #15
	EOR R4, R4, R12, ROR #15
	/* Z = X xor ROL64(Y,19). */
	EOR R9, R9, R4, ROR #12
	EOR R11, R11, R5,  ROR #11
	EOR R12, R12, R6, ROR #11
	EOR R10, R10, R7, ROR #11
	/* C = Y xor ROL64(Z,3). */
	EOR R5,  R5,  R10
	EOR R6, R6, R9, ROR #15
	EOR R7, R7, R11, ROR #15
	EOR R4, R4, R12, ROR #15
	/* D = Z xor ROL64(C,19). */
	EOR R9, R9, R4, ROR #12
	EOR R11, R11, R5,  ROR #11
	EOR R12, R12, R6, ROR #11
	EOR R10, R10, R7, ROR #11
	/* M = C xor D. */
	EOR R5,  R5,  R9
	EOR R6, R6, R11
	EOR R7, R7, R12
	EOR R4, R4, R10
	.if \low
		EOR R0, R0, R5,  LSL #16
		EOR R1, R1, R6, LSL #16
		EOR R2, R2, R7, LSL #16
		EOR R3, R3, R4, LSL #16
	.else
		EOR R0, R0, R5,  LSR #16
		EOR R1, R1, R6, LSR #16
		EOR R2, R2, R7, LSR #16
		EOR R3, R3, R4, LSR #16
	.endif
.endm


.macro LLBC_op_round_function low
.if \low
	uxth R4, R0  //R4 = R0 & #0x0000ffff
	uxth R5, R1
	uxth R6, R2
	uxth R7, R3
.else
	LSR R4, R0, #16
	LSR R5, R1, #16
	LSR R6, R2, #16
	LSR R7, R3, #16
.endif
	
	//Replication storage method
	//R4 = X0 || X0; R5 = X1 || X1; R6 = X2 || X2; R7 = X3 || X3.
	ORR R4, R4, R4, LSL #16
	ORR R5, R5, R5, LSL #16
	ORR R6, R6, R6, LSL #16
	ORR R7, R7, R7, LSL #16
	
	//L_i <<< 3:
	ROR R4, R4, #15
	ROR R5, R5, #15
	ROR R6, R6, #15
	
        S1_box R7, R4, R5, R6, R8

	ldmia R14!, {R9-R12}
	.if \low
		EOR R0, R0, R9
		EOR R1, R1, R10
		EOR R2, R2, R11
		EOR R3, R3, R12
		//Addroundkey
		uxth R9,  R0  
		uxth R10, R1
		uxth R11, R2
		uxth R12, R3
	.else
		//Addroundkey
		EOR R0, R0, R9,  ror #16
		EOR R1, R1, R10, ror #16
		EOR R2, R2, R11, ror #16
		EOR R3, R3, R12, ror #16
		LSR R9,  R0, #16
		LSR R10, R1, #16
		LSR R11, R2, #16
		LSR R12, R3, #16
	.endif

	//Replication storage method
	orr R9,  R9,  R9,  lsl #16
	orr R10, R10, R10, lsl #16
	orr R11, R11, R11, lsl #16
	orr R12, R12, R12, lsl #16

	//<<<19 
	ROR R9, R9, #11
	ROR R10, R10, #11
	ROR R11, R11, #11
	ROR R12, R12, #12
	
	S2_box R12, R9, R10, R11, R8

	MixWord \low
.endm


.macro SWAPMOVE  in0, in1, M, n, tmp   
    eor     \tmp, \in1, \in0, lsr \n
    and     \tmp, \tmp,\M
    eor     \in1, \in1, \tmp
    eor     \in0, \in0, \tmp, lsl \n
.endm


@ void LLBC_encrypt_block(u32 *out, const u32* rkey,
@       const u32 *block0, const u32* block1) {
.global LLBC_encrypt_block
.type   LLBC_encrypt_block,%function
LLBC_encrypt_block:
PUSH    {R4-R11, R14}
SUB     SP, SP, #LOCAL_SIZE
STR     R0, [SP, #PT_PTR]
STR     R1, [SP, #RK_PTR]
STR     R1, [SP, #ENC_RK_PTR]

//loading plaintext
LDR     R8, [SP, #PT_PTR]
LDMIA   R8, {R0-R3}


//intput bit reordering
SWAPMOVE  R1, R0, #0x0f0f0f0f, #4, R8
SWAPMOVE  R3, R2, #0x0f0f0f0f, #4, R8
SWAPMOVE  R1, R0, #0x55555555, #1, R8
SWAPMOVE  R3, R2, #0x55555555, #1, R8
SWAPMOVE  R1, R0, #0x00ff00ff, #8, R8
SWAPMOVE  R3, R2, #0x00ff00ff, #8, R8
SWAPMOVE  R1, R0, #0x33333333, #2, R8
SWAPMOVE  R3, R2, #0x33333333, #2, R8
lsr R5, R1,#16
bfi R1, R0,#16,#16
bfi R0, R5, #0, #16
lsr R5, R3,#16
bfi R3, R2,#16,#16
bfi R2, R5, #0, #16
SWAPMOVE  R1, R0, #0x0f0f0f0f, #4, R8
SWAPMOVE  R3, R2, #0x0f0f0f0f, #4, R8
SWAPMOVE  R1, R0, #0x00ff00ff, #8, R8
SWAPMOVE  R3, R2, #0x00ff00ff, #8, R8
lsr R5, R2,#16
bfi R2, R0,#16,#16
bfi R0, R5, #0, #16
lsr R5, R3,#16
bfi R3, R1,#16,#16
bfi R1, R5, #0, #16

LDR R14, [SP, #ENC_RK_PTR]

LLBC_op_round_function 0
LLBC_op_round_function 1
LLBC_op_round_function 0
LLBC_op_round_function 1
LLBC_op_round_function 0
LLBC_op_round_function 1
LLBC_op_round_function 0
LLBC_op_round_function 1
LLBC_op_round_function 0
LLBC_op_round_function 1
LLBC_op_round_function 0
LLBC_op_round_function 1
LLBC_op_round_function 0
LLBC_op_round_function 1
LLBC_op_round_function 0
LLBC_op_round_function 1
LLBC_op_round_function 0
LLBC_op_round_function 1
LLBC_op_round_function 0
LLBC_op_round_function 1

//Output bit reordering
lsr R5, R2,#16
bfi R2, R0,#16,#16
bfi R0, R5, #0, #16
lsr R5, R3,#16
bfi R3, R1,#16,#16
bfi R1, R5, #0, #16
SWAPMOVE  R1, R0, #0x00ff00ff, #8, R8
SWAPMOVE  R3, R2, #0x00ff00ff, #8, R8
SWAPMOVE  R1, R0, #0x0f0f0f0f, #4, R8
SWAPMOVE  R3, R2, #0x0f0f0f0f, #4, R8
lsr R5, R1,#16
bfi R1, R0,#16,#16
bfi R0, R5, #0, #16
lsr R5, R3,#16
bfi R3, R2,#16,#16
bfi R2, R5, #0, #16
SWAPMOVE  R1, R0, #0x33333333, #2, R8
SWAPMOVE  R3, R2, #0x33333333, #2, R8
SWAPMOVE  R1, R0, #0x00ff00ff, #8, R8
SWAPMOVE  R3, R2, #0x00ff00ff, #8, R8
SWAPMOVE  R1, R0, #0x55555555, #1, R8
SWAPMOVE  R3, R2, #0x55555555, #1, R8
SWAPMOVE  R1, R0, #0x0f0f0f0f, #4, R8 
SWAPMOVE  R3, R2, #0x0f0f0f0f, #4, R8
LDR     R8, [SP, #PT_PTR]
STMIA   R8, {R0-R3}
ADD     SP, SP, #LOCAL_SIZE
POP     {R4-R11, PC}

