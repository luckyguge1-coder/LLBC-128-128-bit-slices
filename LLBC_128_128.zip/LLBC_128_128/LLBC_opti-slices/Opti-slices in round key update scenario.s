.syntax unified
.cpu cortex-m3
.thumb

.equ PT_PTR,      0       /* SP+0：plaintext address */
.equ RK_PTR,      4       /* SP+4：key update address*/
.equ ENC_RK_PTR,  8       /* SP+8：rkey address*/
.equ LOCAL_SIZE, 12       /* get 12 byte */


.macro ror_16bit   in, out, M0, M1, n0, n1, tmp
	and     \tmp, \M0, \in, lsr \n0
	and     \out, \in, \M1
	orr     \out, \tmp, \out, lsl \n1
.endm

.macro S1_box  in0, in1, in2, in3, tmp
	/* 12-instruction, five-register circuit.  Both 16-bit copies are processed together.
	 * Input x3/x2/x1/x0 is in in0/in1/in2/in3; output
	 * output y3/y2/y1/y0 is left in in2/in3/in0/in1. */
	EOR    \in1, \in1, \in2
	ORR   \tmp, \in0, \in1
	EOR   \in2, \in2, \tmp
	AND   \tmp, \in2, \in3
	EOR   \in1, \in1, \tmp
	BIC   \tmp, \in3, \in1
	EOR   \in0, \in0, \tmp
	EOR   \in1,\in1, \in2
	ORN   \tmp, \in1, \in0
	EOR   \in3, \in3, \tmp
	AND   \tmp, \in0, \in3
	EOR   \in1, \in1, \tmp
.endm

.macro S2_box  in0, in1, in2, in3, tmp
	/* 13-instruction, five-register circuit. Both 16-bit copies are 
	 * processed together.  Input x3/x2/x1/x0 is in in0/in1/in2/in3; 
	 * output y3/y2/y1/y0 is left in in1/in3/in0/in2. */
	EOR   \in1, \in1, \in2
	ORN   \tmp, \in3, \in1
	EOR   \in0, \in0, \tmp
	ORN   \tmp, \in1, \in0
	EOR   \in2, \in2, \tmp
	ORR   \tmp, \in2, \in3
	EOR   \in0, \in0, \tmp
	BIC   \tmp, \in3, \in2
	EOR   \in1, \in1, \tmp
	BIC   \tmp, \in0, \in1
	EOR   \in3, \in3, \tmp
	AND   \tmp, \in0, \in3
	EOR   \in1, \in1, \tmp
.endm

/* Input A=S1 in R5/R6/R7/R4; B=S2 in R9/R11/R12/R10.
 * A and B are duplicated in both halfwords.  low selects the state half
 * that receives M(A,B). */
.macro MixWord low
	/* X = A xor B. */
	EOR R9, R9, R5
	EOR R11, R11, R6
	EOR R12, R12, R7
	EOR R10, R10, R4
	/* Y = A xor ROL64(X,3). */
	EOR R5,  R5,  R10
	EOR R6, R6, R9, ROR #15
	EOR R7, R7, R11, ROR #15
	EOR R4, R4, R12, ROR #15
	/* Z = X xor ROL64(Y,19). */
	EOR R9, R9, R4, ROR #12
	EOR R11, R11, R5,  ROR #11
	EOR R12, R12, R6, ROR #11
	EOR R10, R10, R7, ROR #11
	/* C = Y xor ROL64(Z,3). */
	EOR R5,  R5,  R10
	EOR R6, R6, R9, ROR #15
	EOR R7, R7, R11, ROR #15
	EOR R4, R4, R12, ROR #15
	/* D = Z xor ROL64(C,19). */
	EOR R9, R9, R4, ROR #12
	EOR R11, R11, R5,  ROR #11
	EOR R12, R12, R6, ROR #11
	EOR R10, R10, R7, ROR #11
	/* M = C xor D. */
	EOR R5,  R5,  R9
	EOR R6, R6, R11
	EOR R7, R7, R12
	EOR R4, R4, R10
	.if \low
		EOR R0, R0, R5,  LSL #16
		EOR R1, R1, R6, LSL #16
		EOR R2, R2, R7, LSL #16
		EOR R3, R3, R4, LSL #16
	.else
		EOR R0, R0, R5,  LSR #16
		EOR R1, R1, R6, LSR #16
		EOR R2, R2, R7, LSR #16
		EOR R3, R3, R4, LSR #16
	.endif
.endm


.macro LLBC_op_round_function low
.if \low
	uxth R4, R0  //R4 = R0 & #0x0000ffff
	uxth R5, R1
	uxth R6, R2
	uxth R7, R3
.else
	LSR R4, R0, #16
	LSR R5, R1, #16
	LSR R6, R2, #16
	LSR R7, R3, #16
.endif
	
	//Replication storage method
	//R4 = X0 || X0; R5 = X1 || X1; R6 = X2 || X2; R7 = X3 || X3.
	ORR R4, R4, R4, LSL #16
	ORR R5, R5, R5, LSL #16
	ORR R6, R6, R6, LSL #16
	ORR R7, R7, R7, LSL #16
	
	//L_i <<< 3:
	ROR R4, R4, #15
	ROR R5, R5, #15
	ROR R6, R6, #15

	S1_box R7, R4, R5, R6, R8

	ldmia R14!, {R9-R12}
	.if \low
		EOR R0, R0, R9
		EOR R1, R1, R10
		EOR R2, R2, R11
		EOR R3, R3, R12
		//Addroundkey
		uxth R9,  R0  
		uxth R10, R1
		uxth R11, R2
		uxth R12, R3
	.else
		//Addroundkey
		EOR R0, R0, R9,  ror #16
		EOR R1, R1, R10, ror #16
		EOR R2, R2, R11, ror #16
		EOR R3, R3, R12, ror #16
		LSR R9,  R0, #16
		LSR R10, R1, #16
		LSR R11, R2, #16
		LSR R12, R3, #16
	.endif
	//Replication storage method
	orr R9,  R9,  R9,  lsl #16
	orr R10, R10, R10, lsl #16
	orr R11, R11, R11, lsl #16
	orr R12, R12, R12, lsl #16
	
	//<<<19 
	ROR R9, R9, #11
	ROR R10, R10, #11
	ROR R11, R11, #11
	ROR R12, R12, #12
	
	S2_box R12, R9, R10, R11, R8

	MixWord \low
.endm

//In  rkey update, the 128-bit initial key is stored in four 32-bit registers R9~R12. At this point, the round key update is preprocessed, so plaintext storage is not considered. Registers R0~R3, R4~R7, and R8 are all free registers.
//R9 || R10 ||R11 ||R12 = K_{j} || K_{j+1}
.macro RKEY_update  M0, M1, M2, M3
	EOR   R0, R9,  #((\M0) >> 24)
	EOR   R1, R10, #((\M1) >> 24)
	EOR   R2, R11, #((\M2) >> 24)
	EOR   R3, R12, #((\M3) >> 24)
//Store rkey:
	ldr   R8, [SP, #RK_PTR]
	stmia R8!, {R0-R3}
	str   R8, [SP, #RK_PTR]

//G(K_{j+1})
	AND R3, R12, #0x0000f000
	MOV R14, #0x00001000
	ror_16bit  R9, R0, R14, #0x00007000, #3, #1, R8
	ror_16bit  R10, R1, R14, #0x00007000, #3, #1, R8
	ror_16bit  R11, R2, R14, #0x00007000, #3, #1, R8

	ORR R3, R3, R3, LSR #8
	ORR R0, R0, R0, LSR #8
	ORR R1, R1, R1, LSR #8
	ORR R2, R2, R2, LSR #8

	AND R5, R10, #0x00000f00
	AND R6, R11, #0x00000f00
	AND R7, R12, #0x00000f00
	
	mov R14, #0x01000100
	ror_16bit  R9, R4, R14, #0x07000700, #3, #1, R8

	ORR R3, R3, R5
	ORR R0, R0, R6
	ORR R1, R1, R7
	ORR R2, R2, R4
	ORR R3, R3, R5, LSR #8
	ORR R0, R0, R6, LSR #8
	ORR R1, R1, R7, LSR #8
	ORR R2, R2, R4, LSR #8

	AND R8, R9, #0x000000ff
	EOR R3, R3, R8, LSL #8
	AND R5, R10, #0x000000ff
	EOR R0, R0, R5, LSL #8
	AND R6, R11, #0x000000ff
	EOR R1, R1, R6, LSL #8
	AND R7, R12, #0x000000ff
	EOR R2, R2, R7, LSL #8

//G^{2}(K_{j+1})
    //let K_{j+1} save to low 16 bits of R4~R7
	ORR R4, R3, R9, LSL #16
	ORR R5, R0, R10, LSL #16
	ORR R6, R1, R11, LSL #16
	ORR R7, R2, R12, LSL #16

	AND R3, R7, #0x0000f000
	
	MOV R14, #0x00001000
	ror_16bit  R4, R0, R14, #0x00007000, #3, #1, R8
	ror_16bit  R5, R1, R14, #0x00007000, #3, #1, R8
	ror_16bit  R6, R2, R14, #0x00007000, #3, #1, R8
	
	ORR R3, R3, R3, LSR #8
	ORR R0, R0, R0, LSR #8
	ORR R1, R1, R1, LSR #8
	ORR R2, R2, R2, LSR #8

	AND R8, R4, #0x000000ff
	EOR R3, R3, R8, LSL #8
	AND R8, R5, #0x000000ff
	EOR R0, R0, R8, LSL #8
	AND R8, R6, #0x000000ff
	EOR R1, R1, R8, LSL #8
	AND R8, R7, #0x000000ff
	EOR R2, R2, R8, LSL #8

	AND R4, R4, #0x00000f00
	AND R5, R5, #0x00000f00
	AND R6, R6, #0x00000f00
	AND R7, R7, #0x00000f00

	mov R14, #0x01000100
	ror_16bit  R4, R4, R14, #0x07000700, #3, #1, R8

	EOR R3, R3, R5
	EOR R0, R0, R6
	EOR R1, R1, R7
	EOR R2, R2, R4  
	ORR R3, R3, R5, LSR #8
	ORR R0, R0, R6, LSR #8
	ORR R1, R1, R7, LSR #8
	ORR R2, R2, R4, LSR #8

	EOR R9, R9, R3, LSL #16
	EOR R10, R10, R0, LSL #16
	EOR R11, R11, R1, LSL #16
	EOR R12, R12, R2, LSL #16
	
//AddCound
	EOR R9, R9, #((\M0)>>8)
	EOR R10, R10, #((\M1)>>8)
	EOR R11, R11, #((\M2)>>8)
	EOR R12, R12, #((\M3)>>8)
	
	ROR R9,  R9,  #16
	ROR R10, R10, #16
	ROR R11, R11, #16
	ROR R12, R12, #16
//R9 || R10 || R11 || R12 <= K_{j+1} || K_{j+2}
.endm

.macro SWAPMOVE  in0, in1, M, n, tmp   
    eor     \tmp, \in1, \in0, lsr \n
    and     \tmp, \tmp,\M
    eor     \in1, \in1, \tmp
    eor     \in0, \in0, \tmp, lsl \n
.endm

.macro LLBC_opt_Rkey
	SWAPMOVE  R10, R9, #0x0f0f0f0f, #4, R8
	SWAPMOVE  R12, R11, #0x0f0f0f0f, #4, R8
	SWAPMOVE  R10, R9, #0x55555555, #1, R8
	SWAPMOVE  R12, R11, #0x55555555, #1, R8
	SWAPMOVE  R10, R9, #0x00ff00ff, #8, R8
	SWAPMOVE  R12, R11, #0x00ff00ff, #8, R8
	SWAPMOVE  R10, R9, #0x33333333, #2, R8
	SWAPMOVE  R12, R11, #0x33333333, #2, R8
	lsr R3, R10,#16
	bfi R10, R9,#16,#16
	bfi R9, R3, #0, #16
	lsr R3, R12,#16
	bfi R12, R11,#16,#16
	bfi R11, R3, #0, #16
	SWAPMOVE  R10, R9, #0x0f0f0f0f, #4, R8
	SWAPMOVE  R12, R11, #0x0f0f0f0f, #4, R8
	SWAPMOVE  R10, R9, #0x00ff00ff, #8, R8
	SWAPMOVE  R12, R11, #0x00ff00ff, #8, R8
	lsr R3, R11,#16
	bfi R11, R9,#16,#16
	bfi R9, R3, #0, #16
	lsr R3, R12,#16
	bfi R12, R10,#16,#16
	bfi R10, R3, #0, #16

RKEY_update   0x17000000, 0x58000000, 0xbc000000, 0x30000000  //0-th round
RKEY_update   0x58000000, 0xbc000000, 0x30000000, 0x2e000000  //1-st round
RKEY_update   0xbc000000, 0x30000000, 0x2e000000, 0xb0000000  //2-nd round
RKEY_update   0x30000000, 0x2e000000, 0xb0000000, 0x79000000  //3-rd round
RKEY_update   0x2e000000, 0xb0000000, 0x79000000, 0x60000000  //4-th round
RKEY_update   0xb0000000, 0x79000000, 0x60000000, 0x5c000000  //5-th round
RKEY_update   0x79000000, 0x60000000, 0x5c000000, 0x61000000  //6-th round
RKEY_update   0x60000000, 0x5c000000, 0x61000000, 0xf2000000  //7-th round
RKEY_update   0x5c000000, 0x61000000, 0xf2000000, 0xc0000000  //8-th round
RKEY_update   0x61000000, 0xf2000000, 0xc0000000, 0xb8000000  //9-th round
RKEY_update   0xf2000000, 0xc0000000, 0xb8000000, 0xc2000000  //10-th round
RKEY_update   0xc0000000, 0xb8000000, 0xc2000000, 0xe5000000  //11-th round
RKEY_update   0xb8000000, 0xc2000000, 0xe5000000, 0x81000000  //12-th round
RKEY_update   0xc2000000, 0xe5000000, 0x81000000, 0x71000000  //13-th round
RKEY_update   0xe5000000, 0x81000000, 0x71000000, 0x85000000  //14-th round
RKEY_update   0x81000000, 0x71000000, 0x85000000, 0xcb000000  //15-th round
RKEY_update   0x71000000, 0x85000000, 0xcb000000, 0x03000000  //16-th round
RKEY_update   0x85000000, 0xcb000000, 0x03000000, 0xe2000000  //17-th round
RKEY_update   0xcb000000, 0x03000000, 0xe2000000, 0x0b000000  //18-th round
//19-th round
EOR   R0, R9,  #0x00000003
EOR   R1, R10, #0x000000e2
EOR   R2, R11, #0x0000000b
EOR   R3, R12, #0x00000097
ldr   R8, [SP, #RK_PTR]
stmia R8!, {R0-R3}
str   R8, [SP, #RK_PTR]  
.endm


@ void LLBC_encrypt_block(u32 *out, const u32* rkey,
@       const u32 *block0, const u32* block1) {
.global LLBC_encrypt_block
.type   LLBC_encrypt_block,%function
LLBC_encrypt_block:
PUSH    {R4-R11, R14}
SUB     SP, SP, #LOCAL_SIZE
STR     R0, [SP, #PT_PTR]
STR     R1, [SP, #RK_PTR]
STR     R1, [SP, #ENC_RK_PTR]

//rkey update
LDMIA   R2, {R9-R12}
LLBC_opt_Rkey
//loading plaintext
LDR     R8, [SP, #PT_PTR]
LDMIA   R8, {R0-R3}


//intput bit reordering
SWAPMOVE  R1, R0, #0x0f0f0f0f, #4, R8
SWAPMOVE  R3, R2, #0x0f0f0f0f, #4, R8
SWAPMOVE  R1, R0, #0x55555555, #1, R8
SWAPMOVE  R3, R2, #0x55555555, #1, R8
SWAPMOVE  R1, R0, #0x00ff00ff, #8, R8
SWAPMOVE  R3, R2, #0x00ff00ff, #8, R8
SWAPMOVE  R1, R0, #0x33333333, #2, R8
SWAPMOVE  R3, R2, #0x33333333, #2, R8
lsr R5, R1,#16
bfi R1, R0,#16,#16
bfi R0, R5, #0, #16
lsr R5, R3,#16
bfi R3, R2,#16,#16
bfi R2, R5, #0, #16
SWAPMOVE  R1, R0, #0x0f0f0f0f, #4, R8
SWAPMOVE  R3, R2, #0x0f0f0f0f, #4, R8
SWAPMOVE  R1, R0, #0x00ff00ff, #8, R8
SWAPMOVE  R3, R2, #0x00ff00ff, #8, R8
lsr R5, R2,#16
bfi R2, R0,#16,#16
bfi R0, R5, #0, #16
lsr R5, R3,#16
bfi R3, R1,#16,#16
bfi R1, R5, #0, #16

LDR R14, [SP, #ENC_RK_PTR]

LLBC_op_round_function 0
LLBC_op_round_function 1
LLBC_op_round_function 0
LLBC_op_round_function 1
LLBC_op_round_function 0
LLBC_op_round_function 1
LLBC_op_round_function 0
LLBC_op_round_function 1
LLBC_op_round_function 0
LLBC_op_round_function 1
LLBC_op_round_function 0
LLBC_op_round_function 1
LLBC_op_round_function 0
LLBC_op_round_function 1
LLBC_op_round_function 0
LLBC_op_round_function 1
LLBC_op_round_function 0
LLBC_op_round_function 1
LLBC_op_round_function 0
LLBC_op_round_function 1

//Output bit reordering
lsr R5, R2,#16
bfi R2, R0,#16,#16
bfi R0, R5, #0, #16
lsr R5, R3,#16
bfi R3, R1,#16,#16
bfi R1, R5, #0, #16
SWAPMOVE  R1, R0, #0x00ff00ff, #8, R8
SWAPMOVE  R3, R2, #0x00ff00ff, #8, R8
SWAPMOVE  R1, R0, #0x0f0f0f0f, #4, R8
SWAPMOVE  R3, R2, #0x0f0f0f0f, #4, R8
lsr R5, R1,#16
bfi R1, R0,#16,#16
bfi R0, R5, #0, #16
lsr R5, R3,#16
bfi R3, R2,#16,#16
bfi R2, R5, #0, #16
SWAPMOVE  R1, R0, #0x33333333, #2, R8
SWAPMOVE  R3, R2, #0x33333333, #2, R8
SWAPMOVE  R1, R0, #0x00ff00ff, #8, R8
SWAPMOVE  R3, R2, #0x00ff00ff, #8, R8
SWAPMOVE  R1, R0, #0x55555555, #1, R8
SWAPMOVE  R3, R2, #0x55555555, #1, R8
SWAPMOVE  R1, R0, #0x0f0f0f0f, #4, R8 
SWAPMOVE  R3, R2, #0x0f0f0f0f, #4, R8
LDR     R8, [SP, #PT_PTR]
STMIA   R8, {R0-R3}
ADD     SP, SP, #LOCAL_SIZE
POP     {R4-R11, PC}

