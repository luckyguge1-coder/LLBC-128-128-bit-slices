.syntax unified
.cpu cortex-m3
.thumb

.equ PT_PTR,      0       /* SP+0��plaintext address */
.equ RK_PTR,      4       /* SP+4��key update address*/
.equ ENC_RK_PTR,  8       /* SP+8��rkey address*/
.equ LOCAL_SIZE, 12       /* get 12 byte */


.macro ror_16bit   in, out, M0, M1, n0, n1, tmp
	and     \tmp, \M0, \in, lsr \n0
	and     \out, \in, \M1
	orr     \out, \tmp, \out, lsl \n1
.endm

.macro S1_box  in0, in1, in2, in3, out0, out1, out2, out3    
//R7 in0  R4 in1   R5 in2   R6  in3
//Result: in0=a', out1=b', out2=c', in3=d'; out0/out3 are scratch.
//R14 = 0x0000ffff
//R8 is tmp
//ORN/BIC
/* a': 4 instructions */
ORR R8, R7, R4
AND R12, R7, R5
ORN R9, R12, R8
AND R9, R9, R14, LSL #16
EOR R9, R9, R14, LSL #16

/* b': 6 instructions */
AND R8, R7, R4
ORR R12, R4, R5
EOR R12, R12, R14, LSL #16
ORN R12, R12, R6
ORN R10, R8, R12
EOR R10, R10, R14, LSL #16

/* c': 7 instructions */
AND R8, R4, R6
BIC R8, R7, R8
EOR R8, R8, R14, LSL #16
ORR R12, R7, R5
BIC R12, R6, R12
BIC R11, R8, R12
EOR R11, R11, R14, LSL #16

/* d': 7 instructions */
ORR R8, R7, R6
BIC R8, R5, R8
EOR R8, R8, R14, LSL #16
AND R12, R4, R5
BIC R12, R6, R12
BIC R12, R8, R12
EOR R12, R12, R14, LSL #16
.endm  


.macro S2_box  in0, in1, in2, in3, out0, out1, out2, out3
//R7 in0  R4 in1   R5 in2   R6  in3
//R9 out0  R10 out1  R11 out2  R12 out3
//R4 = 0x0000ffff
//R8 is tmp
//ORN/BIC
/* a': 6 instructions */
ORR R9, R7, R5
EOR R8, R6, R14
AND R12, R4, R5
BIC R8, R8, R12
BIC R9, R9, R8
EOR R9, R9, R14

/* b': 7 instructions */
AND R10, R7, R6
ORN R10, R4, R10
EOR R10, R10, R14
ORR R8, R4, R5
ORN R8, R6, R8
ORN R10, R10, R8
EOR R10, R10, R14

/* c': 7 instructions */
ORR R11, R5, R6
ORN R11, R7, R11
EOR R11, R11, R14
AND R8, R7, R4
ORN R8, R6, R8
ORN R11, R11, R8
EOR R11, R11, R14

/* d': 4 instructions */
ORR R12, R7, R4
AND R8, R7, R5
ORN R12, R8, R12
EOR R12, R12, R14
.endm

.macro MixWord 
UXTH R9,  R9
UXTH R10, R10
UXTH R11, R11
UXTH R12, R12
ORR R7, R9,  R7, LSL #16
ORR R4, R10, R4, LSL #16
ORR R5, R11, R5, LSL #16
ORR R6, R12, R6, LSL #16

EOR R7, R7, R7, LSR #16
EOR R4, R4, R4, LSR #16
EOR R5, R5, R5, LSR #16
EOR R6, R6, R6, LSR #16

LSL R9, R7, #16
LSL R10, R4, #16
LSL R11, R5, #16
LSL R12, R6, #16

mov R14, #0x00010000
ror_16bit R9, R9, R14, #0x7fff7fff, #15, #1, R8
ror_16bit R10, R10, R14, #0x7fff7fff, #15, #1, R8
ror_16bit R11, R11, R14, #0x7fff7fff, #15, #1, R8

EOR R7, R7, R12
EOR R4, R4, R9
EOR R5, R5, R10
EOR R6, R6, R11

LSR R9, R7, #16
LSR R10, R4, #16
LSR R11, R5, #16
LSR R12, R6, #16

mov R14, #0x0000001f
ror_16bit  R9, R9, R14, #0x07ff07ff, #11, #5, R8
ror_16bit  R10, R10, R14, #0x07ff07ff, #11, #5, R8
ror_16bit  R11, R11, R14, #0x07ff07ff, #11, #5, R8
mov R14, #0x0000000f
ror_16bit  R12, R12, R14, #0x0fff0fff, #12, #4, R8

EOR R7, R7, R12
EOR R4, R4, R9
EOR R5, R5, R10
EOR R6, R6, R11

LSL R9, R7, #16
LSL R10, R4, #16
LSL R11, R5, #16
LSL R12, R6, #16

mov R14, #0x00010000
ror_16bit R9, R9, R14, #0x7fff7fff, #15, #1, R8
ror_16bit R10, R10, R14, #0x7fff7fff, #15, #1, R8
ror_16bit R11, R11, R14, #0x7fff7fff, #15, #1, R8

EOR R7, R7, R12
EOR R4, R4, R9
EOR R5, R5, R10
EOR R6, R6, R11

LSR R9, R7, #16
LSR R10, R4, #16
LSR R11, R5, #16
LSR R12, R6, #16

mov R14, #0x0000001f
ror_16bit  R9, R9, R14, #0x07ff07ff, #11, #5, R8
ror_16bit  R10, R10, R14, #0x07ff07ff, #11, #5, R8
ror_16bit  R11, R11, R14, #0x07ff07ff, #11, #5, R8
mov R14, #0x0000000f
ror_16bit  R12, R12, R14, #0x0fff0fff, #12, #4, R8

EOR R7, R7, R12
EOR R4, R4, R9
EOR R5, R5, R10
EOR R6, R6, R11

EOR R7, R7, R7,  LSR #16
EOR R4, R4, R4,  LSR #16
EOR R5, R5, R5,  LSR #16
EOR R6, R6, R6,  LSR #16

LSL  R7, R7, #16
LSL  R4, R4, #16
LSL  R5, R5, #16
LSL  R6, R6, #16

EOR R0, R0, R7, LSR #16
EOR R1, R1, R4, LSR #16
EOR R2, R2, R5, LSR #16
EOR R3, R3, R6, LSR #16
.endm


.macro LLBC_op_round_function
	movw R14, #0xffff
	AND R4, R0, R14, LSL #16
	AND R5, R1, R14, LSL #16
	AND R6, R2, R14, LSL #16
	AND R7, R3, R14, LSL #16
	
	//L_i <<< 3:
	mov R14, #0x00010001
	ror_16bit  R4, R4, R14, #0x7fff7fff, #15, #1, R8
	ror_16bit  R5, R5, R14, #0x7fff7fff, #15, #1, R8
	ror_16bit  R6, R6, R14, #0x7fff7fff, #15, #1, R8
	//R7 || R4 || R5 || R6 <= X0 || X1 || X2 || X3

	movw R14, #0xffff    //R14 = #0x0000ffff
	//S1: input is high of 16 bits R7||R4||R5||R6, R7 = a, R4 = b, R5 = c, R6 = d
	S1_box R7, R4, R5, R6, R9, R10, R11, R12

	MOV R7, R9
	MOV R4, R10
	MOV R5, R11
	MOV R6, R12

	//AddRoundKey:
	LDR   R8, [SP, #ENC_RK_PTR]
	LDMIA R8!, {R9-R12}
	STR   R8, [SP, #ENC_RK_PTR]
	EOR R0, R0, R9, ROR #16
	EOR R1, R1, R10, ROR #16
	EOR R2, R2, R11, ROR #16
	EOR R3, R3, R12, ROR #16

	LSR R9, R0, #16
	LSR R10, R1, #16
	LSR R11, R2, #16
	LSR R12, R3, #16
	
	//<<< 19:
	mov R14, #0x001f001f
	ror_16bit  R9, R9, R14, #0x07ff07ff, #11, #5, R8
	ror_16bit  R10, R10, R14, #0x07ff07ff, #11, #5, R8
	ror_16bit  R11, R11, R14, #0x07ff07ff, #11, #5, R8
	mov R14, #0x000f000f
	ror_16bit  R12, R12, R14, #0x0fff0fff, #12, #4, R8
	
	ORR R7, R7, R12
	ORR R4, R4, R9
	ORR R5, R5, R10
	ORR R6, R6, R11
	
	movw R14, #0xffff
	S2_box R7, R4, R5, R6, R9, R10, R11, R12

	LSR R7, R7, #16
	LSR R4, R4, #16
	LSR R5, R5, #16
	LSR R6, R6, #16

	MixWord

	//Swap lift and right blocks:
	ROR R0, R0, #16
	ROR R1, R1, #16
	ROR R2, R2, #16
	ROR R3, R3, #16
.endm

.macro SWAPMOVE  in0, in1, M, n, tmp   
    eor     \tmp, \in1, \in0, lsr \n
    and     \tmp, \tmp,\M
    eor     \in1, \in1, \tmp
    eor     \in0, \in0, \tmp, lsl \n
.endm 


@ void LLBC_encrypt_block(u32 *out, const u32* rkey,
@       const u32 *block0, const u32* block1) {
.global LLBC_encrypt_block
.type   LLBC_encrypt_block,%function
LLBC_encrypt_block:
PUSH    {R4-R11, R14}
SUB     SP, SP, #LOCAL_SIZE
STR     R0, [SP, #PT_PTR]
STR     R1, [SP, #RK_PTR]
STR     R1, [SP, #ENC_RK_PTR]

//rkey update
LDMIA R2, {R9-R12}
//LLBC_opt_Rkey
//loading plaintext
LDR     R8, [SP, #PT_PTR]
LDMIA   R8, {R0-R3}


//intput bit reordering
SWAPMOVE  R1, R0, #0x0f0f0f0f, #4, R8
SWAPMOVE  R3, R2, #0x0f0f0f0f, #4, R8
SWAPMOVE  R1, R0, #0x55555555, #1, R8
SWAPMOVE  R3, R2, #0x55555555, #1, R8
SWAPMOVE  R1, R0, #0x00ff00ff, #8, R8
SWAPMOVE  R3, R2, #0x00ff00ff, #8, R8
SWAPMOVE  R1, R0, #0x33333333, #2, R8
SWAPMOVE  R3, R2, #0x33333333, #2, R8
MOVW R14, #0xffff
SWAPMOVE  R1, R0, R14, #16, R8
SWAPMOVE  R3, R2, R14, #16, R8
SWAPMOVE  R1, R0, #0x0f0f0f0f, #4, R8
SWAPMOVE  R3, R2, #0x0f0f0f0f, #4, R8
SWAPMOVE  R1, R0, #0x00ff00ff, #8, R8
SWAPMOVE  R3, R2, #0x00ff00ff, #8, R8
SWAPMOVE  R2, R0, R14, #16, R8
SWAPMOVE  R3, R1, R14, #16, R8
LLBC_op_round_function
LLBC_op_round_function
LLBC_op_round_function
LLBC_op_round_function
LLBC_op_round_function
LLBC_op_round_function
LLBC_op_round_function
LLBC_op_round_function
LLBC_op_round_function
LLBC_op_round_function
LLBC_op_round_function
LLBC_op_round_function
LLBC_op_round_function
LLBC_op_round_function
LLBC_op_round_function
LLBC_op_round_function
LLBC_op_round_function
LLBC_op_round_function
LLBC_op_round_function
LLBC_op_round_function
//Output bit reordering
movw R14, #0xffff
SWAPMOVE  R2, R0, R14, #16, R8
SWAPMOVE  R3, R1, R14, #16, R8
SWAPMOVE  R1, R0, #0x00ff00ff, #8, R8
SWAPMOVE  R3, R2, #0x00ff00ff, #8, R8
SWAPMOVE  R1, R0, #0x0f0f0f0f, #4, R8
SWAPMOVE  R3, R2, #0x0f0f0f0f, #4, R8
SWAPMOVE  R1, R0, R14, #16, R8
SWAPMOVE  R3, R2, R14, #16, R8
SWAPMOVE  R1, R0, #0x33333333, #2, R8
SWAPMOVE  R3, R2, #0x33333333, #2, R8
SWAPMOVE  R1, R0, #0x00ff00ff, #8, R8
SWAPMOVE  R3, R2, #0x00ff00ff, #8, R8
SWAPMOVE  R1, R0, #0x55555555, #1, R8
SWAPMOVE  R3, R2, #0x55555555, #1, R8
SWAPMOVE  R1, R0, #0x0f0f0f0f, #4, R8 
SWAPMOVE  R3, R2, #0x0f0f0f0f, #4, R8
LDR     R8, [SP, #PT_PTR]
STMIA   R8, {R0-R3}
ADD     SP, SP, #LOCAL_SIZE
POP     {R4-R11, PC}
